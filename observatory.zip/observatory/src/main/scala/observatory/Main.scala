package observatory

object Main extends App {


}
